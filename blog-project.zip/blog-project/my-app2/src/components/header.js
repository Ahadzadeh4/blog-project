import { Link } from "react-router-dom"


function Header() {
  return (
    <header>
      <div style={{ backgroundColor: "black" }}>
        <Link to="/" style={{ textDecoration: "none", color: "blue" }}>Home</Link>
      </div>

    </header>
  )
}

export default Header