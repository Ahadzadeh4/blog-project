import { useContext, useState } from "react"
import { Articlecontext } from "../App"

// محل ساخت بلاگ
function Blog() {
  const { setArticle } = useContext(Articlecontext)
  const [blog, setCreateBlog] = useState("")
  const blogfunction = () => {
    setArticle(prev => [...prev, blog])
    setCreateBlog("")
  }
  return (
    <div style={{ backgroundColor: "green" }}>
      <textarea
        onChange={(event) => setCreateBlog(event.target.value)}
        value={blog}
        style={{ width: "700px", height: "400px", fontSize: "18px", margin: "20px" }}
      />``
      <button onClick={blogfunction} style={{ width: "50px", height: "50px", fontSize: "18px", borderRadius: "5px", margin: "20px" }}>done</button>
    </div>
  )
}

export default Blog;