import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Blog from "./components/CreateBlog"
import Header from "./components/header"
import { useState, createContext } from 'react';

export const Articlecontext = createContext()
// صفحه اصلی برنامه

function App() {
  const [article, setArticle] = useState([])
  return (
    <div className='App'>
      <Articlecontext.Provider value={{ article, setArticle }}>
        <BrowserRouter>
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/Blog" element={<Blog setArticle={setArticle} />} />
          </Routes>
        </BrowserRouter>
      </Articlecontext.Provider>
    </div>
  )
}

export default App;