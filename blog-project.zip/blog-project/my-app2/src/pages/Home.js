import React from "react"
import { useNavigate } from "react-router-dom"
import { useContext } from "react"
import { Articlecontext } from "../App"
// محل نمایش بلاگ ها
 function Home() {
  const navigate = useNavigate()
  const { article } = useContext(Articlecontext)
  return (
    <React.Fragment>
      <div>
        <h2>Hello ، Welcome to my mini blog web site <br />. If you want to publish a blog, Click here.</h2>
        <div>
          <button onClick={() => { navigate("/Blog") }}>Create</button>
        </div>
      </div>
      <div style={{ backgroundColor: "green", margin: "10px" }}>
        {article.map((blog, index) => {
          return (
            <div key={index}>
              <p>{blog}</p>
            </div>
          )
        })}
      </div>
    </React.Fragment>
  )
}
export default Home;